#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

void leerArreglo(int n, int a[]); //Se declara un prototipo de funci�n de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
void quickSort(int vector[15], int inicio, int fin); //Se declara un prototipo de funci�n de tipo void, que recibe como par�metro tres argumentos de tipo int y no retorna ning�n valor
void muestraArreglo(int n, int a[]); //Se declara un prototipo de funci�n de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor

void leerArreglo(int n, int a[]) //Es la funci�n leerArreglo de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
{
	for(int i=0; i<n; i++) //Es la estructura iterativa for
	{
		printf("Por favor, ingresa el elemento A[%d]: ", i); //Escritura de datos ingresados por teclado
		scanf("%d", &a[i]); //Lectura de datos ingresados por teclado
	}
}

void muestraArregloDesordenado(int n, int a[]) //Es la funci�n muestraArregloDesordenado de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
{
	for (int i=0; i<n; i++) //Es la estructura iterativa for
	{
		printf("[%d]\t", a[i]);
	}
}

void quickSort(int vector[15], int inicio, int fin) //Es la funci�n quickSort de tipo void, que recibe como par�metro tres argumentos de tipo int y no retorna ning�n valor
{
	int pivote, izquierda, derecha, aux; //Se declaran variables de tipo int
	
	if(inicio<fin) //Es la estructura selectiva if
	{
		//Inicializamos el pivote con el primer elemento
		pivote = vector[inicio]; //Se asigna un valor que contiene un arreglo a la variable de tipo int
		//Vamos a ubicar los elementos a la izquierda y derecha del pivote
		izquierda = inicio; //Se asigna un valor a la variable de tipo int
		derecha = fin; //Se asigna un valor a la variable de tipo int
		
		while(izquierda<derecha) //Es la estructura iterativa while
		{
			while(derecha>izquierda && vector[derecha]>pivote) derecha--; //Es la estructura iterativa while
			if(derecha>izquierda) //Es la estructura selectiva if
			{
				vector[izquierda] = vector[derecha]; //Se asigna un valor que contiene un arreglo a la variable arreglo de tipo int 
				izquierda++;
			}
			
			while(izquierda<derecha && vector[izquierda]<pivote) izquierda++; //Es la estructura iterativa while
			if(izquierda<derecha) //Es la estructura selectiva if
			{
				vector[derecha] = vector[izquierda]; //Se asigna un valor que contiene un arreglo a la variable arreglo de tipo int 
				derecha--;
			}
		}
		
		//Vamos a ubicar el pivote en su posici�n
		vector[derecha] = pivote; //Se asigna un valor a la variable arreglo de tipo int
		aux = derecha; //Se asigna un valor a la variable de tipo int
		//Se realizan las llamadas recursivas
		quickSort(vector, inicio, aux-1);
		quickSort(vector, aux+1, fin);
	}
}

void muestraArregloOrdenado(int n, int a[]) //Es la funci�n muestraArregloOrdenado de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
{
	for (int i=0; i<n; i++) //Es la estructura iterativa for
	{
		printf("[%d]\t", a[i]);
	}
	printf("\n");
}

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 5. M\220TODOS DE ORDENAMIENTO Y B\351SQUEDA\nTAREA 7. PROGRAMA VECTOR ORDENADO POR EL M\220TODO DE QUICKSORT.\n\n");
	int vector[15], n = 15; //Se declara una variable arreglo de tipo int, tambi�n se declara una variable de tipo int y se asigna un valor a la variable de tipo int
	printf("Lectura del vector de 15 elementos\n");
	leerArreglo(n, vector); //Se invoca a la funci�n leerArreglo, que recibe como par�metros los argumentos n y vector
	printf("\nImpresi\242n del vector desordenado de 15 elementos\n");
	muestraArregloDesordenado(n, vector); //Se invoca a la funci�n muestraArregloDesordenado, que recibe como par�metros los argumentos n y vector
	quickSort(vector, 0, n-1); //Se invoca a la funci�n quickSort, que recibe como par�metros los argumentos vector, 0 y n-1
	printf("\nImpresi\242n del vector ordenado de 15 elementos por el m\202todo de Quicksort\n");
	muestraArregloOrdenado(n, vector); //Se invoca a la funci�n muestraArregloOrdenado, que recibe como par�metros los argumentos n y vector
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

#include<iostream> //Es una librer�a est�ndar de C++
#include<stdlib.h> //Es una librer�a est�ndar de C
using namespace std; //Es el namespace que hace uso de las entidades de las librer�as est�ndar de C++

int main() //Es la funci�n main de tipo int
{
	cout<<"ASIGNATURA. PROGRAMACI\340N SEGMENTADA\nUNIDAD 2. CONOCIMIENTO DEL LENGUAJE\nTAREA 2. PROGRAMA 2.\n\n";
	int num1, num2, num3; //Se declaran variables de tipo int
	
	cout<<"Por favor, ingresa el primer n\243mero: "; //Escritura de datos ingresados por teclado
	cin>>num1; //Lectura de datos ingresados por teclado
	cout<<"Por favor, ingresa el segundo n\243mero: "; //Escritura de datos ingresados por teclado
	cin>>num2; //Lectura de datos ingresados por teclado
	cout<<"Por favor, ingresa el tercer n\243mero: "; //Escritura de datos ingresados por teclado
	cin>>num3; //Lectura de datos ingresados por teclado
	
	if (num1 > num2 && num2 > num3) //Es la estructura selectiva if else anidada
		cout<<"\nEl n\243mero mayor es "<<num1<<"\nEl n\243mero de en medio es "<<num2<<"\nEl n\243mero menor es "<<num3<<endl;
	else if (num1 > num3 && num3 > num2)
		cout<<"\nEl n\243mero mayor es "<<num1<<"\nEl n\243mero de en medio es "<<num3<<"\nEl n\243mero menor es "<<num2<<endl;
 	else if (num2 > num1 && num1 > num3)
		cout<<"\nEl n\243mero mayor es "<<num2<<"\nEl n\243mero de en medio es "<<num1<<"\nEl n\243mero menor es "<<num3<<endl;
	else if (num2 > num3 && num3 > num1)
		cout<<"\nEl n\243mero mayor es "<<num2<<"\nEl n\243mero de en medio es "<<num3<<"\nEl n\243mero menor es "<<num1<<endl;
	else if (num3 > num1 && num1 > num2)
		cout<<"\nEl n\243mero mayor es "<<num3<<"\nEl n\243mero de en medio es "<<num1<<"\nEl n\243mero menor es "<<num2<<endl;
	else if (num3 > num2 && num2 > num1)
		cout<<"\nEl n\243mero mayor es "<<num3<<"\nEl n\243mero de en medio es "<<num2<<"\nEl n\243mero menor es "<<num1<<endl;
	else if (num1 == num2 && num2 > num3)
		cout<<"\nLos n\243meros mayores son "<<num1<<" y "<<num2<<"\nEl numero menor es "<<num3<<endl;
	else if (num1 == num2 && num2 < num3)
		cout<<"\nEl n\243mero mayor es "<<num3<<"\nLos n\243meros menores son "<<num1<<" y "<<num2<<endl;
	else if (num1 == num3 && num3 > num2)
		cout<<"\nLos n\243meros mayores son "<<num1<<" y "<<num3<<"\nEl n\243mero menor es "<<num2<<endl;
	else if (num1 == num3 && num3 < num2)
		cout<<"\nEl n\243mero mayor es "<<num2<<"\nLos n\243meros menores son "<<num1<<" y "<<num3<<endl;
 	else if (num2 == num3 && num3 > num1)
		cout<<"\nLos n\243meros mayores son "<<num2<<" y "<<num3<<"\nEl n\243mero menor es "<<num1<<endl;
	else if (num2 == num3 && num3 < num1)
		cout<<"\nEl n\243mero mayor es "<<num1<<"\n Los n\243meros menores son "<<num2<<" y "<<num3<<endl;
	else
		cout<<"\nLos n\243meros "<<num1<<", "<<num2<<" y "<<num3<<" son iguales"<<endl;
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

#include<iostream> //Es una librer�a est�ndar de C++
#include<stdlib.h> //Es una librer�a est�ndar de C
using namespace std; //Es el namespace que hace uso de las entidades de las librer�as est�ndar de C++

int main() //Es la funci�n main de tipo int
{
	cout<<"ASIGNATURA. PROGRAMACI\340N SEGMENTADA\nUNIDAD 2. CONOCIMIENTO DEL LENGUAJE\nTAREA 2. PROGRAMA 1.\n\n";
	string nombre; //Se declara una variable de tipo string
	
	cout<<"Por favor, ingresa tu nombre completo: "; //Escritura de datos ingresados por teclado
	getline(cin, nombre); //Funci�n para realizar la lectura de datos ingresados por teclado
	cout<<"Hola!!! "<<nombre<<", \250C\242mo est\240s?"<<endl;
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

void menu(); //Se declara un prototipo de funci�n de tipo void, que no recibe como par�metro ning�n argumento y no retorna ning�n valor  
void sumar(int n1, int n2); //Se declara un prototipo de funci�n de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
void restar(int n1, int n2); //Se declara un prototipo de funci�n de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
void multiplicar(int n1, int n2); //Se declara un prototipo de funci�n de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
void dividir(int n1, int n2); //Se declara un prototipo de funci�n de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor

void menu() //Es la funci�n menu de tipo void, que no recibe como par�metro ning�n argumento y no retorna ning�n valor
{
	char opcion; //Se declara una variable de tipo char
	int n1, n2; //Se declaran variables de tipo int
	
	printf("Calculadora b\240sica. Men\243 de opciones.");
    printf("\n1. Sumar dos n\243meros");
    printf("\n2. Restar dos n\243meros");
    printf("\n3. Multiplicar dos n\243meros");
    printf("\n4. Dividir dos n\243meros");
	printf("\nPor favor, ingrese una opci\242n: "); //Escritura de datos ingresados por teclado
    scanf("%c", &opcion); //Lectura de datos ingresados por teclado
    printf("\nIntroduzca un primer n\243mero: "); //Escritura de datos ingresados por teclado
	scanf("%d", &n1); //Lectura de datos ingresados por teclado
    printf("Introduzca un segundo n\243mero: "); //Escritura de datos ingresados por teclado
    scanf( "%d", &n2); //Lectura de datos ingresados por teclado
	
	switch (opcion) //Es la estructura selectiva m�ltiple switch
	{
		case '1': sumar(n1, n2); //Se invoca a la funci�n sumar, que recibe como par�metros los argumentos n1 y n2
		break;
		case '2': restar(n1, n2); //Se invoca a la funci�n restar, que recibe como par�metros los argumentos n1 y n2
		break;
		case '3': multiplicar(n1, n2); //Se invoca a la funci�n multiplicar, que recibe como par�metros los argumentos n1 y n2
		break;
		case '4': dividir(n1, n2); //Se invoca a la funci�n dividir, que recibe como par�metros los argumentos n1 y n2
		break;
		default: printf("Opci\242n incorrecta.\n");
		break;	
	}
	
}

void sumar(int n1, int n2) //Es la funci�n sumar de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
{
	printf("El resultado de la suma es: %d + %d = %d\n", n1, n2, n1 + n2);
}

void restar(int n1, int n2) //Es la funci�n restar de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
{
	printf("El resultado de la resta es: %d - %d = %d\n", n1, n2, n1 - n2);
}

void multiplicar(int n1, int n2) //Es la funci�n multiplicar de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
{
	printf("El resultado de la multiplicaci\242n es: %d * %d = %d\n", n1, n2, n1 * n2);
}

void dividir(int n1, int n2) //Es la funci�n dividir de tipo void, que recibe como par�metro dos argumentos de tipo int y no retorna ning�n valor
{
	if (n2 != 0) //Es la estructura selectiva if else
    	printf("El resultado de la divisi\242n es: %d / %d = %d (Residuo = %d)\n", n1, n2, n1 / n2, n1 % n2);
    else
        printf("ERROR: No se puede dividir entre cero.\n");
}

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 3. MODULARIDAD: PROCEDIMIENTOS Y FUNCIONES\nTAREA 4. PROGRAMA 2.\n\n");
	menu(); //Se invoca a la funci�n menu, que no recibe como par�metro ning�n argumento
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

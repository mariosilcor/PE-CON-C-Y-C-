#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C
#include <math.h> //Es una librer�a est�ndar de C

int cubo(int ndatos) //Es la funci�n cubo de tipo int, que recibe como par�metro un argumento de tipo int
{
	int i; //Se declara una variable de tipo int
	for(i = 1; i <= ndatos; i++) //Es la estructura iterativa for
	{
		printf("El cubo del n\243mero %d es: %.f\n", i, pow(i, 3)); //La funci�n pow viene de la librer�a est�ndar math.h
	}
	return i; //La funci�n cubo devuelve un valor de tipo int
}

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 3. MODULARIDAD: PROCEDIMIENTOS Y FUNCIONES\nTAREA 4. PROGRAMA 1.\n\n");
	int ndatos = 10; //Se declara y se asigna una variable de tipo int, que ser� el argumento dentro del par�metro de la funci�n cubo
	cubo(ndatos); //Se invoca a la funci�n cubo, que recibe como par�metro el argumento ndatos
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

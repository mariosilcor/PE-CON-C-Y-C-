#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

int ulam() //Es la funci�n ulam de tipo int, que no recibe como par�metro ning�n argumento de tipo int
{
	int num; //Se declara una variable de tipo int
	printf("Construcci\242n de la serie de ULAM a partir del n\243mero dado por el usuario."); 
	printf("\nPor favor, ingrese un n\243mero: "); //Escritura de datos ingresados por teclado
	scanf("%d", &num); //Lectura de datos ingresados por teclado
	printf("\nImpresi\242n de la serie de ULAM a partir del n\243mero ingresado por teclado.\n"); //Es un salto de l�nea
	
	if (num > 0) //Es la primera estructura selectiva if else
	{
		printf("\t\t\t\t\t[%d]", num);
		while(num != 1) //Es la estructura iterativa while
		{
			printf("\n"); //Es un salto de l�nea
			if (num%2 == 0) //Es la segunda estructura selectiva if else
			{
				num = num/2;
			}
			else
			{
				num = num*3+1;
			}
			printf("\t\t\t\t\t[%d]", num);
		}
	}
	else
	{
		printf("El n\243mero debe ser mayor a cero");
	}
	printf("\n"); //Es un salto de l�nea
	return 0; //La funci�n ulam devuelve un valor de tipo int
}

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 3. MODULARIDAD: PROCEDIMIENTOS Y FUNCIONES\nTAREA 4. PROGRAMA 3.\n\n");
	ulam(); //Se invoca a la funci�n ulam, que no recibe como par�metro ning�n argumento
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

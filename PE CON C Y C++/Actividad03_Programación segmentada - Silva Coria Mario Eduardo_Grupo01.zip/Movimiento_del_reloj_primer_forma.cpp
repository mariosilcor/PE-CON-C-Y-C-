#include<iostream> //Es una librer�a est�ndar de C++
#include<stdlib.h> //Es una librer�a est�ndar de C
using namespace std; //Es el namespace que hace uso de las entidades de las librer�as est�ndar de C++

int main(int argc, char *argv[ ]) //Es la funci�n main del tipo de retorno int, con dos par�metros formales: una variable int argc y una variable char *argv
{
	cout<<"ASIGNATURA. PROGRAMACI\340N SEGMENTADA\nUNIDAD 3. SENTENCIAS REPETITIVAS\nTAREA 3. PROGRAMA 1.\n\n";
	int hora, min, seg; //Se declaran variables de tipo int
   
	cout<<"Movimiento del reloj - Programa utilizando sentencias for anidadas.\n"<<endl;
	for (hora=0; hora <=23; hora++) //Es la estructura iterativa for
	{
		for (min=0; min <=59; min++) //Es la estructura iterativa for
		{
			for (seg=0; seg <=59; seg++) //Es la estructura iterativa for
			{
				cout<<hora<<":"<<min<<":"<<seg<<endl; //Se va imprimiendo la simulaci�n de un reloj, cada vez que el usuario pulse cualquier tecla    
				system("pause"); //Es un comando para detener el programa 
			}
		}
	}
	return EXIT_SUCCESS; //La funci�n main del tipo de retorno int devuelve una finalizaci�n exitosa
}

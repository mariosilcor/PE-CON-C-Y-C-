#include<iostream> //Es una librer�a est�ndar de C++
#include<stdlib.h> //Es una librer�a est�ndar de C
using namespace std; //Es el namespace que hace uso de las entidades de las librer�as est�ndar de C++

int main() //Es la funci�n main de tipo int
{
	cout<<"ASIGNATURA. PROGRAMACI\340N SEGMENTADA\nUNIDAD 3. SENTENCIAS REPETITIVAS\nTAREA 3. PROGRAMA 2.\n\n";
	int hora = 0, min = 0, seg = 0; //Se declaran variables de tipo int y se asignan valores a las variables de tipo int
	bool ciclo = true; //Se declara una variable de tipo bool y se asigna un valor true a la variable de tipo bool
	
	cout<<"Movimiento del reloj - Programa utilizando la sentencia while y sentencias if.\n"<<endl;
	while(ciclo) //Es la estructura iterativa while
	{
		cout<<hora<<":"<<min<<":"<<seg<<endl; //Se va imprimiendo la simulaci�n de un reloj, cada vez que el usuario pulse cualquier tecla    
		system("pause"); //Es un comando para detener el programa 
		seg++;
		
		if (seg == 60) //Es la estructura selectiva if
		{
			min++;
			seg = 0;
		}
		
		if (min == 60) //Es la estructura selectiva if
		{
			hora++;
			min = 0;
		}
		
		if (hora == 24) //Es la estructura selectiva if
		{
			hora = 0;
			seg = 0;
			min = 0;
		}
	}
	return 0; //La funci�n main devuelve un valor de tipo int
}

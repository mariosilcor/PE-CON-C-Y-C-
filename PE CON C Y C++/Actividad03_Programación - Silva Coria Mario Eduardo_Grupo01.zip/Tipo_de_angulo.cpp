#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 2. TIPOS DE ESTRUCTURAS\nTAREA 3. PROGRAMA 2.\n\n");
	int angulo; //Se declara una variable de tipo int
	
	printf("Por favor, ingrese la medida del \240ngulo: "); //Escritura de datos ingresados por teclado
	scanf("%d", &angulo); //Lectura de datos ingresados por teclado
	
	if (angulo<=0 || angulo>=360) //Es la estructura selectiva if else anidada
		printf("\nEl \240ngulo que ingres\242 no tiene clasificaci\242n\n");
	else if (angulo < 90)
		printf("\nEl \240ngulo que ingres\242 es agudo\n");
	else if (angulo == 90)
		printf("\nEl \240ngulo que ingres\242 es recto\n");
	else if (angulo < 180)
		printf("\nEl \240ngulo que ingres\242 es obtuso\n");
	else if (angulo == 180)
		printf("\nEl \240ngulo que ingres\242 es llano\n");
	else
		printf("\nEl \240ngulo que ingres\242 es c\242ncavo\n");
    system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 2. TIPOS DE ESTRUCTURAS\nTAREA 3. PROGRAMA 1.\n\n");
	int d1, d2, d5, d10, d20, d50, d100, d200, d500, d1000, cambio, dinero; //Se declaran variables de tipo int
	
	printf("Por favor, ingrese el dinero que quieres retirar del cajero: "); //Escritura de datos ingresados por teclado
	scanf("%d", &dinero); //Lectura de datos ingresados por teclado
	
	printf("\nEl dinero que retiraste es el siguiente.");
	if (dinero >= 1000) //Es la estructura selectiva if
    {
    	d1000 = dinero/1000;
    	cambio = dinero%1000;
    	dinero = cambio;
    	printf("\nBilletes de 1000 pesos: %d", d1000);
    }
    if (dinero >= 500) //Es la estructura selectiva if
    {
    	d500 = dinero/500;
    	cambio = dinero%500;
    	dinero = cambio;
    	printf("\nBilletes de 500 pesos: %d", d500);
    }
    if (dinero >= 200) //Es la estructura selectiva if
    {
    	d200 = dinero/200;
    	cambio = dinero%200;
    	dinero = cambio;
    	printf("\nBilletes de 200 pesos: %d", d200);
    }
    if (dinero >= 100) //Es la estructura selectiva if
    {
    	d100 = dinero/100;
    	cambio = dinero%100;
    	dinero = cambio;
    	printf("\nBilletes de 100 pesos: %d", d100);
    }
    if (dinero >= 50) //Es la estructura selectiva if
    {
    	d50 = dinero/50;
    	cambio = dinero%50;
    	dinero = cambio;
    	printf("\nBilletes de 50 pesos: %d", d50);
    }
    if (dinero >= 20) //Es la estructura selectiva if
    {
    	d20 = dinero/20;
    	cambio = dinero%20;
    	dinero = cambio;
    	printf("\nBilletes de 20 pesos: %d", d20);
    }
    if (dinero >= 10) //Es la estructura selectiva if
    {
    	d10 = dinero/10;
    	cambio = dinero%10;
    	dinero = cambio;
    	printf("\nMonedas de 10 pesos: %d", d10);
    }
    if (dinero >= 5) //Es la estructura selectiva if
    {
    	d5 = dinero/5;
    	cambio = dinero%5;
    	dinero = cambio;
    	printf("\nMonedas de 5 pesos: %d", d5);
    }
    if (dinero >= 2) //Es la estructura selectiva if
    {
    	d2 = dinero/2;
    	cambio = dinero%2;
    	dinero = cambio;
    	printf("\nMonedas de 2 pesos: %d", d2);
    }
    if (dinero >= 1) //Es la estructura selectiva if
    {
    	d1 = dinero/1;
    	cambio = dinero%1;
    	dinero = cambio;
    	printf("\nMonedas de 1 peso: %d", d1);
    }
    printf("\n");
    system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

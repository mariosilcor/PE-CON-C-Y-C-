#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

void lectura(int x[5][5], int m, int n) //Es la funci�n lectura de tipo void, que recibe como par�metro tres argumentos de tipo int y no retorna ning�n valor
{
	int i, j; //Se declaran variables de tipo int
	for(i=0; i<m; i++) //Es la estructura iterativa for
		for(j=0; j<n; j++) //Es la estructura iterativa for
		{
			printf("Por favor, ingresa el elemento A[%d][%d]: ", i, j); //Escritura de datos ingresados por teclado
			scanf("%d", &x[i][j]); //Lectura de datos ingresados por teclado
		}
}

void muestra(int x[5][5], int m, int n) //Es la funci�n muestra de tipo void, que recibe como par�metro tres argumentos de tipo int y no retorna ning�n valor
{
	int i, j; //Se declaran variables de tipo int
	for(i=0; i<m; i++) //Es la estructura iterativa for
	{
		for(j=0; j<n; j++) //Es la estructura iterativa for
			printf("[%d] \t", x[i][j]);
		printf("\n");
	}
}

void simetrica(int x[5][5], int m, int n) //Es la funci�n simetrica de tipo void, que recibe como par�metro tres argumentos de tipo int y no retorna ning�n valor
{
	int i, j; //Se declaran variables de tipo int
	char bandera = 'V'; //Se declara una variable de tipo char y se asigna un caracter a la variable de tipo char
	for(i=0; i<m; i++) //Es la estructura iterativa for
	{
		for(j=0; j<n; j++) //Es la estructura iterativa for
		{
			if(x[i][j] != x[j][i]) //Es la estructura selectiva if
			{
				bandera = 'F'; //Se asigna un caracter a la variable de tipo char
			}
		}
	}
	
	if(bandera == 'V') //Es la estructura selectiva if else 
	{
		printf("\nEl arreglo bidimensional s\241 es sim\202trico\n");
	}
	else 
	{
		printf("\nEl arreglo bidimensional no es sim\202trico\n");
	}
} 

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 4. ARREGLOS\nTAREA 6. PROGRAMA ARREGLO BIDIMENSIONAL SIM\220TRICO DE 5X5.\n\n");
	int arreglo[5][5], filas = 5, columnas = 5; //Se declara una variable arreglo de tipo int, tambi�n se declaran variables de tipo int y se asignan valores a las variables de tipo int
	printf("Lectura del arreglo bidimensional de 5x5\n");
	lectura(arreglo, filas, columnas); //Se invoca a la funci�n lectura, que recibe como par�metros los argumentos arreglo, filas y columnas
	printf("\nImpresi\242n del arreglo bidimensional de 5x5\n");
	muestra(arreglo, filas, columnas); //Se invoca a la funci�n muestra, que recibe como par�metros los argumentos arreglo, fila y columnas
	simetrica(arreglo, filas, columnas); //Se invoca a la funci�n simetrica, que recibe como par�metros los argumentos arreglo, fila y columnas
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

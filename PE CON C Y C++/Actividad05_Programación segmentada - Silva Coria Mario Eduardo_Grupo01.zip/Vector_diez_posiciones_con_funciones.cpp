#include<iostream> //Es una librer�a est�ndar de C++
#include<stdlib.h> //Es una librer�a est�ndar de C
using namespace std; //Es el namespace que hace uso de las entidades de las librer�as est�ndar de C++

int tamanioVector(int tamanio) //Es la funci�n tamanioVector de tipo int, que recibe como par�metro un argumento de tipo int
{
	int auxi = 0, auxj = 0, posicion = 0, menor; //Se declaran variables de tipo int y se asignan valores a las variables de tipo int
	int vector[10]; //Se declara un arreglo unidimensional de tipo int
	
	for (int i=0; i<tamanio; i++) //Es la estructura iterativa for
	{
		cout<<"Por favor, ingresa el elemento X["<<i<<"]: "; //Escritura de datos ingresados por teclado
		cin>>vector[i]; //Lectura de datos ingresados por teclado
		if(auxi < vector[i]) //Es la estructura selectiva if
			auxi = vector[i];
	}
	menor = auxi;
	
	for (int i=0; i<tamanio; i++) //Es la estructura iterativa for
	{
		if(menor > vector[i]) //Es la estructura selectiva if
			menor = vector[i];
	}
	
	while (posicion<tamanio && auxj==0) //Es la estructura iterativa while
	{
		if (menor == vector[posicion]) //Es la estructura selectiva if else
			auxj = 1;
		else
			posicion++; 
	}
	
	cout<<"\nEl n\243mero m\240s peque\244o de los valores capturados es el "<<menor<<", y est\240 en la posici\242n ["<<posicion<<"] dentro del arreglo"<<endl;
	return posicion; //La funci�n tamanioVector devuelve un valor de tipo int
}

int main() //Es la funci�n main de tipo int
{
	cout<<"ASIGNATURA. PROGRAMACI\340N SEGMENTADA\nUNIDAD 5. MODULARIDAD\nTAREA 5. PROGRAMA 3.\n\n";
	int tamanio = 10; //Se declara y se asigna una variable de tipo int, que ser� el argumento dentro del par�metro de la funci�n tamanioVector
	tamanioVector(tamanio); //Se invoca a la funci�n tamanioVector, que recibe como par�metro el argumento tamanio
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int	
}

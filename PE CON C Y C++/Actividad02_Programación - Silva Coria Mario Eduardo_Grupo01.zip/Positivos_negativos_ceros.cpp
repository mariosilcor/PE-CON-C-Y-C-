#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 2. TIPOS DE ESTRUCTURAS\nTAREA 2. PROGRAMA 3.\n\n");
	int ndatos, numero, positivos = 0, negativos = 0, ceros = 0; //Se declaran variables de tipo int y se asignan valores a las variables de tipo int
	
	printf("Por favor, ingrese el n\243mero de datos a ingresar: "); //Escritura de datos ingresados por teclado
	scanf("%d", &ndatos); //Lectura de datos ingresados por teclado
	
	if (ndatos > 0) //Es la estructura selectiva if
	{
		for (int i = 1; i <= ndatos; i++) //Es la estructura iterativa for
		{
			printf("Ingrese el n\243mero %d: ", i); //Escritura de datos ingresados por teclado
			scanf("%d", &numero); //Lectura de datos ingresados por teclado
			
			if (numero > 0) //Es la estructura selectiva if else anidada
				positivos++;
			else if (numero < 0)
				negativos++;
			else
				ceros++;
		}
	}
	printf("\nLa cantidad de n\243meros positivos es de: %d\n", positivos);
	printf("La cantidad de n\243meros negativos es de: %d\n", negativos);
	printf("La cantidad de n\243meros iguales a cero es de: %d\n", ceros);
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 2. TIPOS DE ESTRUCTURAS\nTAREA 2. PROGRAMA 1.\n\n");
	int antiguedad, categoria, clave; //Se declaran variables de tipo int
	
	printf("Por favor, ingrese la clave del empleado: "); //Escritura de datos ingresados por teclado
	scanf("%d", &clave); //Lectura de datos ingresados por teclado
	printf("Por favor, ingrese el valor de la categor\241a del empleado: "); //Escritura de datos ingresados por teclado
	scanf("%d", &categoria); //Lectura de datos ingresados por teclado
	printf("Por favor, ingrese el valor de la antig\201edad del empleado: "); //Escritura de datos ingresados por teclado
	scanf("%d", &antiguedad); //Lectura de datos ingresados por teclado
	
	if (((categoria == 3 || categoria == 4) && antiguedad > 5) || (categoria == 2 && antiguedad > 7)) //Es la estructura selectiva if else
		printf("\nEl empleado con clave (%d) s\241 reune las condiciones para el puesto de trabajo.\n", clave);
	else
		printf("\nEl empleado con clave (%d) no reune las condiciones para el puesto de trabajo.\n", clave);
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

#include <stdio.h> //Es una librer�a est�ndar de C
#include <stdlib.h> //Es una librer�a est�ndar de C

int main() //Es la funci�n main de tipo int
{
	printf("ASIGNATURA. PROGRAMACI\340N\nUNIDAD 2. TIPOS DE ESTRUCTURAS\nTAREA 2. PROGRAMA 2.\n\n");
	int ndatos, numero, sumapar = 0, sumaimp = 0, contadorimp = 0; //Se declaran variables de tipo int y se asignan valores a las variables de tipo int
	
	printf("Por favor, ingrese el n\243mero de datos a ingresar: "); //Escritura de datos ingresados por teclado
	scanf("%d", &ndatos); //Lectura de datos ingresados por teclado
	
	if (ndatos > 0) //Es la estructura selectiva if
	{
		for (int i = 1; i <= ndatos; i++) //Es la estructura iterativa for
		{
			printf("Ingrese el n\243mero %d: ", i); //Escritura de datos ingresados por teclado
			scanf("%d", &numero); //Lectura de datos ingresados por teclado
			
			if (numero%2 == 0) //Es la estructura selectiva if else
				sumapar = sumapar + numero;
			else
			{
				sumaimp = sumaimp + numero;
				contadorimp++;
			}
		}
	}
	printf("\nLa suma de los n\243meros pares es de: %d\n", sumapar);
	printf("El promedio de los n\243meros impares es de: %5.2f\n", (float)sumaimp/contadorimp);
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int
}

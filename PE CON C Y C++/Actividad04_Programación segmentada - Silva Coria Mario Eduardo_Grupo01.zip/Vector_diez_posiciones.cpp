#include<iostream> //Es una librer�a est�ndar de C++
#include<stdlib.h> //Es una librer�a est�ndar de C
using namespace std; //Es el namespace que hace uso de las entidades de las librer�as est�ndar de C++

int main() //Es la funci�n main de tipo int
{
	cout<<"ASIGNATURA. PROGRAMACI\340N SEGMENTADA\nUNIDAD 4. ESTRUCTURAS DE DATOS\nTAREA 4. PROGRAMA VECTOR DE 10 POSICIONES.\n\n";
	int tamanio = 10, auxi = 0, auxj = 0, posicion = 0, menor; //Se declaran variables de tipo int y se asignan valores a las variables de tipo int
	int vector[10]; //Se declara un arreglo unidimensional de tipo int
	
	for (int i=0; i<tamanio; i++) //Es la estructura iterativa for
	{
		cout<<"Por favor, ingresa el elemento X["<<i<<"]: ";
		cin>>vector[i];	
		if(auxi < vector[i]) //Es la estructura selectiva if
			auxi = vector[i];
	}
	menor = auxi;
	
	for (int i=0; i<tamanio; i++) //Es la estructura iterativa for
	{
		if(menor > vector[i]) //Es la estructura selectiva if
			menor = vector[i];
	}
	
	while (posicion<tamanio && auxj==0) //Es la estructura iterativa while
	{
		if (menor == vector[posicion]) //Es la estructura selectiva if else
			auxj = 1;
		else
			posicion++;
	}
	
	cout<<"\nEl n\243mero m\240s peque\244o de los valores capturados es el "<<menor<<", y est\240 en la posici\242n ["<<posicion<<"] dentro del arreglo"<<endl;
	system("pause"); //Es un comando para detener el programa
	return 0; //La funci�n main devuelve un valor de tipo int	
}

//Programa 2
#include<iostream> //Es una librer�a est�ndar de C++
#include<stdlib.h> //Es una librer�a est�ndar de C
using namespace std; //Es el namespace que hace uso de las entidades de las librer�as est�ndar de C++

struct package //Se declara un registro package de tipo struct
{
    int q; //Se declara una variable de tipo int
};

void set_value(struct package *d_ptr, int value) //Es la funci�n set_value de tipo void, que recibe como par�metro dos argumentos de tipo int y de tipo puntero a tipo struct, y no retorna ning�n valor
{
    d_ptr->q = value; //Se asigna un valor a un objeto de tipo puntero a tipo d_ptr
}

int main() //Es la funci�n main de tipo int
{
	cout<<"ASIGNATURA. PROGRAMACI\340N SEGMENTADA\nUNIDAD 6. PUNTEROS\nTAREA 6. PROGRAMA MUESTRA VALOR 20.\n\n";
    struct package p; //Se declara un objeto de tipo p que invoca al registro package de tipo struct
    p.q = 10; //Se asigna un valor a un objeto de tipo p
    set_value(&p, 20); //Se invoca a la funci�n set_value, que recibe como par�metros los argumentos 20 y la direcci�n de memoria del objeto p
    printf("Value = %d\n", p.q); //Se imprime el valor que contiene el objeto p
    system("PAUSE"); //Es un comando para detener el programa
    return EXIT_SUCCESS; //La funci�n main del tipo de retorno int devuelve una finalizaci�n exitosa
}
